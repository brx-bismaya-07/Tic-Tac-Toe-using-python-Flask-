from flask import Flask, render_template, request

app = Flask(__name__)

board = [""] * 9
current_player = "X"
winner = None

def check_winner():
    global winner
    win_conditions = [
        (0,1,2),(3,4,5),(6,7,8),
        (0,3,6),(1,4,7),(2,5,8),
        (0,4,8),(2,4,6)
    ]
    for a, b, c in win_conditions:
        if board[a] == board[b] == board[c] and board[a] != "":
            winner = board[a]

@app.route("/", methods=["GET", "POST"])
def index():
    global current_player

    if request.method == "POST":
        move = int(request.form["move"])
        if board[move] == "" and winner is None:
            board[move] = current_player
            check_winner()
            current_player = "O" if current_player == "X" else "X"

    return render_template("index.html", board=board, winner=winner)

@app.route("/reset")
def reset():
    global board, current_player, winner
    board = [""] * 9
    current_player = "X"
    winner = None
    return render_template("index.html", board=board, winner=winner)

if __name__ == "__main__":
    app.run(debug=True)
